from utils.server import ChatServer

if __name__ == '__main__':
    chat_server = ChatServer()
    chat_server.start_server()
